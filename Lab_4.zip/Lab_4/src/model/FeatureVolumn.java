/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author danica
 */

public class FeatureVolumn extends Feature {

    private String name;
    public FeatureVolumn(Product owner) {
        super(owner);
        this.name = "volumn";
        this.setName(name);
    }

}

